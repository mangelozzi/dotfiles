/*The primary Rhyming Dictionary application routine.
  Copyright (C) 2000,2001,2002 Brian Langenberger
  Released under the terms of the GNU Public License.
  See the file "COPYING" for full details.*/

char *getWord(int flags);
