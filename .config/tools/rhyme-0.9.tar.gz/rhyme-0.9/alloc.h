#include <stdio.h>
#include <stdlib.h>

void *testalloc(size_t size);
