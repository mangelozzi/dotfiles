#include <stdio.h>
#include <stdlib.h>

/*A program to merge the lines of two files to standard output.
  Copyright (C) 2000,2001,2002 Brian Langenberger
  Released under the terms of the GNU Public License.
  See the file "COPYING" for full details.*/

FILE *openFile(char *name);

